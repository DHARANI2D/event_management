package com.example.adp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdpApplicationTests {

	@Test
	void contextLoads() {
	}

}
